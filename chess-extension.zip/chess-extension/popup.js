document.addEventListener('DOMContentLoaded', function() {
  const startBtn = document.getElementById('start');
  const stopBtn = document.getElementById('stop');
  const testVoiceBtn = document.getElementById('testVoice');
  const resetSystemBtn = document.getElementById('resetSystem');
  const volumeUpBtn = document.getElementById('volumeUp');
  const volumeDownBtn = document.getElementById('volumeDown');
  const statusDiv = document.getElementById('status');
  const movesDiv = document.getElementById('moves');

  let speechRate = 0.8;

  // Probar voz con ejemplos reales
  testVoiceBtn.addEventListener('click', function() {
    const examples = [
      'Ejemplo: Caballo f 3',
      'Ejemplo: Dama captura e 5',
      'Ejemplo: e 4',
      'Ejemplo: captura d 5',
      'Ejemplo: Enroque corto',
      'Ejemplo: Torre a 1 jaque'
    ];
    
    examples.forEach((example, index) => {
      setTimeout(() => {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
          if (tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, {
              action: 'TEST_VOICE_ES',
              text: example
            });
          }
        });
      }, index * 2000);
    });
  });

  // Reinicio completo del sistema
  resetSystemBtn.addEventListener('click', function() {
    statusDiv.textContent = '🔄 Reiniciando sistema...';
    statusDiv.className = 'status disconnected';
    
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      if (tabs[0]) {
        // Recargar la pestaña y reiniciar
        chrome.tabs.reload(tabs[0].id, {}, function() {
          setTimeout(() => {
            chrome.tabs.sendMessage(tabs[0].id, {action: 'start'});
            statusDiv.textContent = '✅ Sistema reiniciado';
            statusDiv.className = 'status connected';
          }, 2000);
        });
      }
    });
  });

  // Control de velocidad
  volumeUpBtn.addEventListener('click', function() {
    speechRate = Math.min(1.5, speechRate + 0.1);
    updateSpeechRate();
  });

  volumeDownBtn.addEventListener('click', function() {
    speechRate = Math.max(0.5, speechRate - 0.1);
    updateSpeechRate();
  });

  function updateSpeechRate() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, {
          action: 'SET_SPEECH_RATE',
          rate: speechRate
        });
      }
    });
  }

  startBtn.addEventListener('click', function() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, {action: 'start'});
        statusDiv.textContent = '✅ Leyendo jugadas...';
        statusDiv.className = 'status connected';
      } else {
        statusDiv.textContent = '❌ Abre chess.com o lichess.org';
        statusDiv.className = 'status disconnected';
      }
    });
  });

  stopBtn.addEventListener('click', function() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, {action: 'stop'});
      }
    });
    statusDiv.textContent = '⏹️ Detenido';
    statusDiv.className = 'status disconnected';
  });

  function updateMoves() {
    chrome.storage.local.get(['movesHistory'], function(result) {
      if (result.movesHistory && result.movesHistory.length > 0) {
        const moves = result.movesHistory.slice(-8).reverse();
        movesDiv.innerHTML = '<h4>📝 Últimas Jugadas:</h4>' + 
          moves.map(move => 
            `<div class="move-item" data-move-number="${move.moveNumber}">
              <div>
                <span class="move-number">${move.moveNumber}.</span>
                <span class="move-text">${move.spanishMove || move.move}</span>
              </div>
              <div class="site-info">
                🕒 ${new Date(move.timestamp).toLocaleTimeString()}
              </div>
            </div>`
          ).join('');
      } else {
        movesDiv.innerHTML = '<p>No hay jugadas registradas.</p>';
      }
    });
  }

  // Actualizar cada segundo
  setInterval(updateMoves, 1000);
  updateMoves();
});