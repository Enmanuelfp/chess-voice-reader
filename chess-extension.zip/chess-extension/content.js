class ChessMovesReader {
  constructor() {
    this.isMonitoring = false;
    this.lastMove = '';
    this.moveCount = 0;
    this.speechRate = 0.8;
    this.isSpeaking = false;
    this.speechQueue = [];
    this.init();
  }

  init() {
    console.log('Sistema Algebraico FIDE Español - Activado');
  }

  startMonitoring() {
    this.isMonitoring = true;
    this.setupObservers();
    this.checkForMoves();
    this.speakText('Sistema algebraico FIDE español activado');
    console.log('Monitoreo iniciado');
  }

  stopMonitoring() {
    this.isMonitoring = false;
    this.speakText('Sistema desactivado');
    console.log('Monitoreo detenido');
  }

  setupObservers() {
    const observer = new MutationObserver((mutations) => {
      if (this.isMonitoring) {
        this.extractMoves();
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });
  }

  extractMoves() {
    let moves = [];
    
    if (window.location.hostname.includes('chess.com')) {
      moves = this.extractChessComMoves();
    } else if (window.location.hostname.includes('lichess.org')) {
      moves = this.extractLichessMoves();
    }

    if (moves.length > 0) {
      const latestMove = moves[moves.length - 1];
      if (latestMove !== this.lastMove && this.isValidAlgebraicMove(latestMove)) {
        this.lastMove = latestMove;
        this.moveCount++;
        this.processAndSpeakMove(latestMove);
      }
    }
  }

  extractChessComMoves() {
    const moves = [];
    
    console.log('=== BUSCANDO MOVIMIENTOS EN CHESS.COM ===');
    
    // BUSCAR EN TODOS LOS ELEMENTOS POSIBLES
    const allElements = document.querySelectorAll('*');
    
    allElements.forEach(element => {
      // Solo elementos hoja (sin hijos) para evitar duplicados
      if (element.children.length === 0) {
        const text = element.textContent?.trim();
        
        if (text && this.isValidAlgebraicMove(text)) {
          console.log('Movimiento detectado:', text, element);
          moves.push(text);
        }
      }
    });

    // Estrategia específica para elementos de chess.com
    const chessSelectors = [
      '.move',
      '.move-text',
      '.move-text-component',
      '[data-whole-move-number]',
      '.node',
      '.san',
      'span',
      'div',
      'button'
    ];

    chessSelectors.forEach(selector => {
      try {
        const elements = document.querySelectorAll(selector);
        elements.forEach(element => {
          const text = element.textContent?.trim();
          if (text && this.isValidAlgebraicMove(text)) {
            console.log(`En selector ${selector}:`, text);
            if (!moves.includes(text)) {
              moves.push(text);
            }
          }
        });
      } catch (e) {
        console.log('Error en selector:', selector, e);
      }
    });

    console.log('Total movimientos encontrados:', moves);
    return moves;
  }

  extractLichessMoves() {
    const moves = [];
    const selectors = [
      '.move',
      '.san',
      '.l4x',
      '.node'
    ];
    
    selectors.forEach(selector => {
      document.querySelectorAll(selector).forEach(element => {
        const move = element.textContent?.trim();
        if (move && this.isValidAlgebraicMove(move)) {
          moves.push(move);
        }
      });
    });
    
    return moves;
  }

  isValidAlgebraicMove(move) {
    // Excluir números de movimientos
    if (/^\d+\.?$/.test(move)) return false;
    if (/^\d/.test(move)) return false;
    
    // PATRONES DEL SISTEMA ALGEBRAICO FIDE ESPAÑOL
    const patterns = [
      // Peones simples: e4, e5, d4, etc.
      /^[a-h][1-8][+#]?$/,
      
      // Peones capturando: exd5, dxe4, etc.
      /^[a-h]x[a-h][1-8][+#]?$/,
      
      // Piezas moviendo: Cf3, Ad3, Te1, etc.
      /^[RDTA C][a-h]?[1-8]?[a-h][1-8][+#]?$/,
      
      // Piezas capturando: Cxf3, Axd3, Txe1, etc.
      /^[RDTA C][a-h]?[1-8]?x[a-h][1-8][+#]?$/,
      
      // Enroques
      /^O-O(-O)?[+#]?$/,
      
      // Promociones: e8=D, d1=T, etc.
      /^[a-h][1-8]=[RDTA C][+#]?$/,
      
      // Promociones capturando: exd8=D, etc.
      /^[a-h]x[a-h][1-8]=[RDTA C][+#]?$/
    ];
    
    const isValid = patterns.some(pattern => pattern.test(move)) && 
                   move.length >= 2 && move.length <= 6;
    
    if (isValid) {
      console.log('✅ Movimiento algebraico válido:', move);
    }
    
    return isValid;
  }

  processAndSpeakMove(move) {
    const spokenMove = this.convertToSpokenAlgebraic(move);
    
    const moveData = {
      type: 'NEW_MOVE',
      move: move,
      spokenMove: spokenMove,
      site: window.location.hostname,
      timestamp: new Date().toISOString(),
      moveNumber: this.moveCount
    };
    
    chrome.runtime.sendMessage(moveData);
    this.addToSpeechQueue(spokenMove);
  }

  convertToSpokenAlgebraic(move) {
    console.log('Convirtiendo a voz:', move);
    
    // 1. ENROQUES
    if (move === 'O-O') return 'Enroque corto';
    if (move === 'O-O-O') return 'Enroque largo';
    
    let spoken = '';
    let isCapture = move.includes('x');
    let check = '';
    
    // 2. DETECTAR JAQUE Y JAQUE MATE
    if (move.includes('#')) {
      check = ' jaque mate';
      move = move.replace('#', '');
    } else if (move.includes('+')) {
      check = ' jaque';
      move = move.replace('+', '');
    }
    
    // 3. DETECTAR PROMOCIÓN
    let promotion = '';
    if (move.includes('=')) {
      const parts = move.split('=');
      move = parts[0];
      const promotedPiece = this.getPieceName(parts[1].charAt(0));
      promotion = ` coronando ${promotedPiece}`;
    }
    
    // 4. QUITAR CAPTURA TEMPORALMENTE
    if (isCapture) {
      move = move.replace('x', '');
    }
    
    // 5. IDENTIFICAR TIPO DE MOVIMIENTO
    const firstChar = move.charAt(0);
    
    if ('RDTA C'.includes(firstChar)) {
      // ES UNA PIEZA
      const pieceName = this.getPieceName(firstChar);
      const rest = move.substring(1);
      
      // Manejar ambigüedades (Cbd2, T1e1, etc.)
      if (rest.length > 2) {
        const coordinates = rest.substring(rest.length - 2);
        const disambiguation = rest.substring(0, rest.length - 2);
        
        if (isCapture) {
          spoken = `${pieceName} ${disambiguation} captura ${this.saySquare(coordinates)}`;
        } else {
          spoken = `${pieceName} ${disambiguation} ${this.saySquare(coordinates)}`;
        }
      } else {
        // Movimiento normal de pieza
        if (isCapture) {
          spoken = `${pieceName} captura ${this.saySquare(rest)}`;
        } else {
          spoken = `${pieceName} ${this.saySquare(rest)}`;
        }
      }
    } else {
      // ES UN PEÓN
      if (isCapture) {
        // Captura de peón: exd5 → "peón e captura d cinco"
        const fromFile = move.charAt(0);
        const toSquare = move.substring(1);
        spoken = `captura ${this.saySquare(toSquare)}`;
      } else {
        // Movimiento simple de peón: e4 → "e cuatro"
        spoken = this.saySquare(move);
      }
    }
    
    spoken += promotion + check;
    
    console.log('🎯 Movimiento vocal:', spoken);
    return spoken;
  }

  getPieceName(pieceChar) {
    const pieces = {
      'R': 'Rey',
      'D': 'Dama', 
      'T': 'Torre',
      'A': 'Alfil',
      'C': 'Caballo'
    };
    return pieces[pieceChar] || pieceChar;
  }

  saySquare(square) {
    if (square.length < 2) return square;
    
    const file = square.charAt(0);
    const rank = square.charAt(1);
    
    // Decir "e cuatro" en lugar de "e 4"
    const rankNames = {
      '1': 'uno', '2': 'dos', '3': 'tres', '4': 'cuatro',
      '5': 'cinco', '6': 'seis', '7': 'siete', '8': 'ocho'
    };
    
    return `${file} ${rankNames[rank] || rank}`;
  }

  // SISTEMA DE COLA PARA NO CORTAR JUGADAS
  addToSpeechQueue(text) {
    this.speechQueue.push(text);
    this.processSpeechQueue();
  }

  processSpeechQueue() {
    if (this.isSpeaking || this.speechQueue.length === 0) {
      return;
    }
    
    this.isSpeaking = true;
    const text = this.speechQueue.shift();
    
    this.speakText(text).then(() => {
      this.isSpeaking = false;
      setTimeout(() => {
        this.processSpeechQueue();
      }, 400);
    });
  }

  speakText(text) {
    return new Promise((resolve) => {
      if (!window.speechSynthesis) {
        console.error('Speech Synthesis no disponible');
        resolve();
        return;
      }
      
      const speech = new SpeechSynthesisUtterance();
      speech.text = text;
      speech.lang = 'es-ES';
      speech.rate = this.speechRate;
      speech.pitch = 1;
      speech.volume = 1;
      
      speech.onend = () => {
        console.log('🔊 Voz completada:', text);
        resolve();
      };
      
      speech.onerror = (error) => {
        console.error('Error en voz:', error);
        resolve();
      };
      
      console.log('🔊 Anunciando:', text);
      window.speechSynthesis.speak(speech);
    });
  }

  setSpeechRate(rate) {
    this.speechRate = rate;
  }

  checkForMoves() {
    setInterval(() => {
      if (this.isMonitoring) {
        this.extractMoves();
      }
    }, 1500);
  }
}

// Inicializar
const chessReader = new ChessMovesReader();

// Comunicación
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.action) {
    case 'start':
      chessReader.startMonitoring();
      break;
    case 'stop':
      chessReader.stopMonitoring();
      window.speechSynthesis.cancel();
      chessReader.isSpeaking = false;
      chessReader.speechQueue = [];
      break;
    case 'TEST_VOICE_ES':
      const examples = [
        'e cuatro',
        'Caballo f tres', 
        'Alfil captura c cuatro',
        'Dama e cinco jaque',
        'Torre a uno',
        'Enroque corto',
        'captura d cinco',
        'Rey g uno',
        'e ocho coronando Dama'
      ];
      examples.forEach((example, index) => {
        setTimeout(() => {
          chessReader.addToSpeechQueue(example);
        }, index * 2000);
      });
      break;
    case 'SET_SPEECH_RATE':
      chessReader.setSpeechRate(request.rate);
      break;
    case 'DEBUG_DETECTION':
      // Función de debug para ver qué se detecta
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          function: debugDetection
        });
      });
      break;
  }
});

// Función de debug mejorada
function debugDetection() {
  console.log('=== DEBUG DETECCIÓN MOVIMIENTOS ===');
  
  // Buscar en elementos específicos de chess.com
  const specificSelectors = [
    '.move', '.move-text', '.move-text-component', 
    '[data-whole-move-number]', '.node', '.san'
  ];
  
  specificSelectors.forEach(selector => {
    const elements = document.querySelectorAll(selector);
    console.log(`🔍 ${selector}: ${elements.length} elementos`);
    elements.forEach((el, idx) => {
      if (idx < 10) {
        console.log(`  [${idx}]: "${el.textContent?.trim()}"`, el);
      }
    });
  });
  
  // Buscar movimientos en cualquier texto
  console.log('=== BUSCANDO PATRONES DE MOVIMIENTOS ===');
  const allText = document.body.innerText;
  const movePatterns = [
    /\b([RDTA C][a-h]?[1-8]?x?[a-h][1-8][+#]?)\b/g,
    /\b([a-h]x?[a-h]?[1-8]=?[RDTA C]?[+#]?)\b/g,
    /\b(O-O(-O)?[+#]?)\b/g
  ];
  
  movePatterns.forEach(pattern => {
    const matches = allText.match(pattern);
    if (matches) {
      console.log(`Patrón ${pattern}:`, matches.slice(0, 10));
    }
  });
}