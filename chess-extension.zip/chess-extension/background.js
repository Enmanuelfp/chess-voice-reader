let movesHistory = [];

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'NEW_MOVE') {
    console.log('Nueva jugada detectada:', message);
    
    movesHistory.push(message);
    
    // Mantener solo las últimas 30 jugadas (más conservador)
    if (movesHistory.length > 30) {
      movesHistory = movesHistory.slice(-30);
    }
    
    // Guardar en almacenamiento
    chrome.storage.local.set({ movesHistory: movesHistory });
    
    // Mostrar notificación
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIHZpZXdCb3g9IjAgMCA0OCA0OCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjQ4IiBoZWlnaHQ9IjQ4IiBmaWxsPSIjNENBQTVDIi8+CjxwYXRoIGQ9Ik0xMiAzNkMxNS4zMTM3IDM2IDE4IDMzLjMxMzcgMTggMzBWMTguNUwxOCAxMkMxOCA4LjY4NjI5IDIwLjY4NjMgNiAyNCA2QzI3LjMxMzcgNiAzMCA4LjY4NjI5IDMwIDEyVjE4LjVWMzBDMzAgMzMuMzEzNyAzMi42ODYzIDM2IDM2IDM2QzM5LjMxMzcgMzYgNDIgMzMuMzEzNyA0MiAzMEM0MiAyNi42ODYzIDM5LjMxMzcgMjQgMzYgMjRWMjhDMzcuMTA0NiAyOCAzOCAyOC44OTU0IDM4IDMwQzM4IDMxLjEwNDYgMzcuMTA0NiAzMiAzNiAzMkMzNC44OTU0IDMyIDM0IDMxLjEwNDYgMzQgMzBWMThWMTJDMzQgNi40NzcxNSAyOS41MjI4IDIgMjQgMkMxOC40NzcyIDIgMTQgNi40NzcxNSAxNCAxMlYxOFYzMEMxNCAzMS4xMDQ2IDEzLjEwNDYgMzIgMTIgMzJDMTAuODk1NCAzMiAxMCAzMS4xMDMgMTAgMzBDMTAgMzAuNDQ3NyAxMC40NDc3IDMwIDExIDMwQzExLjU1MjMgMzAgMTIgMzAuNDQ3NyAxMiAzMVYzMEMxMiAzMS4xMDQ2IDEyLjg5NTQgMzIgMTQgMzJWMzBDMTQgMzMuMzEzNyAxNi42ODYzIDM2IDIwIDM2QzIzLjMxMzcgMzYgMjYgMzMuMzEzNyAyNiAzMFYxOC41VjEyQzI2IDkuNzkwODYgMjQuMjA5MSA4IDIyIDhDMTkuNzkwOSA4IDE4IDkuNzkwODYgMTggMTJWMTguNVYzMEMxOCAzMy4zMTM3IDIwLjY4NjMgMzYgMjQgMzZWMzZDMTcuMzcyNiAzNiAxMiAzMC42Mjc0IDEyIDI0QzEyIDE3LjM3MjYgMTcuMzcyNiAxMiAyNCAxMkMzMC42Mjc0IDEyIDM2IDE3LjM3MjYgMzYgMjRDMzYgMzAuNjI3NCAzMC42Mjc0IDM2IDI0IDM2SDEyWiIgZmlsbD0id2hpdGUiLz4KPC9zdmc+',
      title: 'Nueva Jugada - Chess Voice ES',
      message: `Jugada ${message.moveNumber}: ${message.spanishMove}`,
      priority: 1
    });
  }
});

// Inicializar almacenamiento
chrome.storage.local.get(['movesHistory'], function(result) {
  if (result.movesHistory) {
    movesHistory = result.movesHistory;
  }
});

// Limpiar historial cuando se cierra la extensión
chrome.runtime.onSuspend.addListener(() => {
  movesHistory = [];
  chrome.storage.local.set({ movesHistory: [] });
});